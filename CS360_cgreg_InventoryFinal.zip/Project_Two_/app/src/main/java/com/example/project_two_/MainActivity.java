package com.example.project_two_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Hashmap implementation of login to circumvent lack of working SQLite DB.
    Map loginDB = new HashMap();
    public EditText user;
    public EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeLoginDB(); // Set a base admin profile

        user = (EditText) findViewById(R.id.username);
        pass = (EditText) findViewById(R.id.password);
    }

    // Creates a base admin profile with the username "admin" and password "password".
    private void initializeLoginDB() {
        loginDB.put("admin", "password");
    }

    // If the user does not have an existing account creates one using the inputted credentials and logs in to the app.
    public void onCreateAccount(View view) {
        Intent logIntent = new Intent(this, InventoryActivity.class);
        if(!loginDB.containsKey(user.getText().toString())) {
            if(user.getText().toString() != null && pass.getText().toString() != null) {
                loginDB.put(user.getText().toString(), pass.getText().toString());
                startActivity(logIntent);
            }
        }
    }

    // Verifies user credentials then logs in allowing access to the app.
    public void onLoginClicked(View view) {
        Intent logIntent = new Intent(this, InventoryActivity.class);
        Intent failIntent = new Intent(this, MainActivity.class);
        if(user.getText().toString() != null && pass.getText().toString() != null) {
            if (loginDB.get(user.getText().toString()).equals(pass.getText().toString())) {
                startActivity(logIntent);
            }
            else if (user.getText().toString().equals("") || pass.getText().toString().equals("")) {
                startActivity(failIntent);
            }
        }
    }
}