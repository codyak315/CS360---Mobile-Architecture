package com.example.project_two_;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class PermissionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
    }


    // Switches activity to Inventory.
    public void onAcceptClicked(View view) {
        Intent logIntent = new Intent(this, InventoryActivity.class);
        startActivity(logIntent);
    }


    // Switches activity to Inventory.
    public void onDenyClicked(View view) {
        Intent logIntent = new Intent(this, InventoryActivity.class);
        startActivity(logIntent);
    }


}
