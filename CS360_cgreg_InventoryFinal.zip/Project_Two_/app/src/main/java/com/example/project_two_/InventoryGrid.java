package com.example.project_two_;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;
import android.widget.SimpleCursorAdapter;

public class InventoryGrid extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    
    private static InventoryGrid itemGrid;

    public static InventoryGrid getInstance(Context context) {
        if (itemGrid == null) {
            itemGrid = new InventoryGrid(context);
        }
        return itemGrid;
    }

    /*
    Constructer for SQLite Database to be used in InventoryActivity
     */
    private InventoryGrid(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /*
    Creates a SQLite database with table "Inventory" and columns "Items" and "Count"
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + "Inventory" + " (" +
                "Items" + " text, " +
                "Count" + " float)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + "Inventory");
        onCreate(db);
    }

    /*
    Adds a string to the SQLite Database
     */
    public long addItem(String id, float count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("Items", id);
        values.put("Count", count);

        long itemId = db.insert("Inventory", null, values);
        return itemId;
    }

    /*
    Updates an item in the SQLite Database
     */
    public boolean updateItem(String id, float count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("Items", id);
        values.put("Count", count);

        int rowsUpdated = db.update("Inventory", values, "_id = ?",
                new String[] {id});
        return rowsUpdated > 0;
    }

    /*
    Deletes an item from the SQLite database
     */
    public boolean deleteItem(String id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete("Inventory", "Items" + " = ?",
                new String[] {id});
        return rowsDeleted > 0;
    }

}
