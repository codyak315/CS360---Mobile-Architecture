package com.example.project_two_;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.app.Activity;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import javax.security.auth.Subject;

public class InventoryActivity extends AppCompatActivity {

    private InventoryGrid mInventoryGrid;

    private InventoryAdapter mInventoryAdapter;
    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        mInventoryGrid = InventoryGrid.getInstance(getApplicationContext());
    }


    // Switches activity to Permission Screen.
    public void onAlertClicked(View view) {
        Intent logIntent = new Intent(this, PermissionActivity.class);
        startActivity(logIntent);
    }

    /*
    Code adapted from Zybooks. Couldn't wrap head around how to have SQL Database connect to GridView
     */
    private class InventoryHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private Subject mSubject;
        private TextView mTextView;

        public InventoryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mTextView = itemView.findViewById(R.id.subjectTextView);
        }

        public void bind(Subject inventory, int position){
            mSubject = inventory;
          //  mTextView.setText(inventory.getText());
        }

        @Override
        public void onClick(View view) {
            // Start Activity
            Intent intent = new Intent(InventoryActivity.this, InventoryGrid.class);
          //  intent.putExtra(InventoryGrid.EXTRA_SUBJECT, mSubject.getText());
            startActivity(intent);
        }
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryHolder> {

        private List<Subject> mSubjectList;

        public InventoryAdapter(List<Subject> subjects) {
            mSubjectList = subjects;
        }

        @Override
        public InventoryHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new InventoryHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryHolder holder, int position) {
            holder.bind(mSubjectList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mSubjectList.size();
        }

    }

}



